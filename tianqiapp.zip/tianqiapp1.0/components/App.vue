<template>
    <div id="app">
    </div>
    <router-view></router-view>
</template>
<script>
    export default {
       
    }
</script>
<style></style>